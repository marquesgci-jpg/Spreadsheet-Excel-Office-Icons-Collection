# 📊 Spreadsheet Icons Collection

Uma coleção organizada de ícones profissionais para planilhas, dashboards, ferramentas financeiras e aplicações em Excel/VBA/Web.

## 📁 Estrutura de Categorias

Para manter o repositório organizado e facilitar a localização dos ícones, a estrutura de pastas foi dividida da seguinte forma:

```text
spreadsheet-icons/
├── icons/
│   ├── financeiro/      # Orçamentos, Fluxo de Caixa, DRE, Investimentos, Consórcios
│   ├── dashboards/      # KPIs, Visões Executivas, Gráficos e Indicadores
│   ├── projetos/        # Cronogramas, Gráficos de Gantt, Gestão de Tarefas
│   ├── operacional/     # Controle de Estoque, Vendas, CRM, Faturamento
│   └── utilidades/      # Calculadoras, Formulários, Auxiliares
├── README.md
├── LICENSE
└── CONTRIBUTING.md
```

## 🚀 Como Adicionar Seus Ícones

Basta copiar seus arquivos `.png` para a pasta correspondente dentro de `icons/`:

1. Escolha a categoria correta (ex: `icons/financeiro/`).
2. Cole seus ícones `.png` com nomes claros e descritivos (ex: `fluxo-de-caixa.png`, `kpi-dashboard.png`).
3. Faça o commit e envie para o seu repositório no GitHub:
   ```bash
   git add .
   git commit -m "feat: adiciona novos ícones de planilhas"
   git push origin main
   ```

## 📄 Licença
Distribuído sob a licença MIT. Sinta-se à vontade para usar em seus projetos pessoais e comerciais.
