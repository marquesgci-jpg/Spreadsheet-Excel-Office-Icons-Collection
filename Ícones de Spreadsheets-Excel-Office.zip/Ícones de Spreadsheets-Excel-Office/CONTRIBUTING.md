# Contribuindo com o Repositório

Obrigado pelo interesse em contribuir! Siga estas diretrizes simples para adicionar ou sugerir novos ícones:

1. **Formato:** Apenas arquivos `.png` com fundo transparente (preferencialmente).
2. **Nomenclatura:** Use nomes em *kebab-case* descritivos em português ou inglês (ex: `carteira-investimento.png`).
3. **Organização:** Certifique-se de salvar o ícone na pasta da categoria correta dentro de `icons/`.
